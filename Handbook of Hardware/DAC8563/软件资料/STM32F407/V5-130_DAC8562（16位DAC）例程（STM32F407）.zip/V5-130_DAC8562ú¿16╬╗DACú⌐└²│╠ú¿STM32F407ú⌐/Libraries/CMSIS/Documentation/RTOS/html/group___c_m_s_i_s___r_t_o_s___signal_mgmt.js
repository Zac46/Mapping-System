var group___c_m_s_i_s___r_t_o_s___signal_mgmt =
[
    [ "osFeature_Signals", "group___c_m_s_i_s___r_t_o_s___signal_mgmt.html#ga01edde265710d883b6e237d34a6ef4a6", null ],
    [ "osSignalClear", "group___c_m_s_i_s___r_t_o_s___signal_mgmt.html#ga87283a6ebc31ce9ed42baf3ea7e4eab6", null ],
    [ "osSignalSet", "group___c_m_s_i_s___r_t_o_s___signal_mgmt.html#ga3de2730654589d6c3559c4b9e2825553", null ],
    [ "osSignalWait", "group___c_m_s_i_s___r_t_o_s___signal_mgmt.html#ga38860acda96df47da6923348d96fc4c9", null ]
];